import React, { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom';
import styled from 'styled-components'
import { AddNewVehicleApi, getAllRouteApi, getVehicleDriverApi } from 'src/Utils/Apis';
import toast from 'react-hot-toast';
import DataLoader from 'src/Layouts/Loader';
import { useForm } from 'react-hook-form';

const Container = styled.div`
    .mainBreadCrum{
        --bs-breadcrumb-divider: '>' !important;
    }

    .bredcrumText{
        color: var(--breadCrumTextColor);
    }

    .bredcrumActiveText{
        color: var(--breadCrumActiveTextColor);
    }

    .ActiveState{
        cursor: pointer;
        color: #000;
        border-bottom: 3px solid orange;
    }

    .InActiveState{
        cursor: pointer;
        color: var(--greyState);
    }

    .form-control::placeholder, .form-control, .form-select{
        color: var(--greyState)
    }

    .form-control, .form-select{
        border-radius: 5px;
        box-shadow: none !important;
        border: 1px solid var(--fontControlBorder);
    }

    .AddBtnn, .AddBtnn:visited, .AddBtnn:active{
        border: 1px solid var(--breadCrumActiveTextColor);
        background-color: var(--breadCrumActiveTextColor)
    }

    .CancelBtnn, .CancelBtnn:active{
        border: 1px solid var(--breadCrumActiveTextColor);
    }
`;

const AddVehicle = () => {

    const navigate = useNavigate();
    const token = sessionStorage.getItem('token');
    //loader State
    const [loaderState, setloaderState] = useState(false);
    const [allRouteData, setAllRouteData] = useState([]);
    const [driverData, setDriverData] = useState([]);

    const { register, handleSubmit, formState: { errors }, setValue } = useForm({
        mode: 'onChange'
    });

    useEffect(() => {
        getAllRouteData();
        getAllDriverData();
    }, [token])

    const getAllRouteData = async () => {
        setloaderState(true)
        try {
            var response = await getAllRouteApi('', '', '');
            if (response?.status === 200) {
                if (response?.data?.status === 'success') {
                    setloaderState(false)
                    setAllRouteData(response?.data?.routes);
                }
                else {
                    setloaderState(false)
                    toast.error(response?.data?.message)
                }
            }
            else {
                setloaderState(false)
                toast.error(response?.data?.message)
            }
        }
        catch (error) {
            setloaderState(false);
            setloaderState(false)
            // console.log('Error facing in fetching Routes', error)
            if (error?.response?.data?.statusCode === 401) {
                sessionStorage.removeItem('token')
                setTimeout(() => {
                    navigate('/')
                }, 200);
            }
        }
        finally {
            setloaderState(false);
        }
    }

    const getAllDriverData = async () => {
        setloaderState(true)
        try {
            var response = await getVehicleDriverApi();
            // console.log(response)
            if (response?.status === 200) {
                if (response?.data?.status === 'success') {
                    setloaderState(false)
                    setDriverData(response?.data?.drivers);
                }
                else {
                    setloaderState(false)
                    toast.error(response?.data?.message)
                }
            }
            else {
                setloaderState(false)
                toast.error(response?.data?.message)
            }
        }
        catch (error) {
            setloaderState(false);
            setloaderState(false)
            // console.log('Error facing in fetching Driver', error)
        }
        finally {
            setloaderState(false);
        }
    }

    const AddNewVehicle = async (data) => {
        try {
            setloaderState(true)
            const formData = new FormData();
            formData.append('vehicleNo', data?.vehicleNo),
                formData.append('vehicleModel', data?.vehicleModel),
                formData.append('chassisNo', data?.chassisNo),
                formData.append('driverId', data?.driverId),
                formData.append('totalSeat', data?.totalSeat),
                formData.append('status', data?.status)
                formData.append('routeId', data?.routeId)

            var response = await AddNewVehicleApi(formData);
            // console.log(response, 'add vehicle');
            if (response?.status === 200) {
                if (response?.data?.status === 'success') {
                    setloaderState(false)
                    toast.success(response?.data?.message)
                    setTimeout(() => {
                        navigate('/admin/transport/vehicle');
                    }, 1000);
                }
                else {
                    toast.error(response?.data?.message, 'else 1');
                    setloaderState(false)
                }
            }
            else {
                toast.error(response?.data?.message, 'else 2');
                setloaderState(false)
            }
        }
        catch (error) {
            setloaderState(false);
            toast.error(error);
            // console.log(error, 'catch error')
            setloaderState(false)
        }
        finally {
            setloaderState(false);
        }
    }

    const handleCancelBtn = async () => {
        navigate('/admin/transport/vehicle')
    }

    return (
        <>
            <Container>
                {loaderState && (<DataLoader />)}
                <div className="container-fluid p-4">
                    <div className="row pb-3">
                        <nav className='mainBreadCrum font14 ps-0' aria-label="breadcrumb">
                            <ol className="breadcrumb mb-1">
                                <li className="breadcrumb-item"><a href="/" className='bredcrumText text-decoration-none'>Home</a></li>
                                <li className="breadcrumb-item"><a href="/admin/transport/route" className='bredcrumText text-decoration-none'>Transport</a></li>
                                <li className="breadcrumb-item"><a href="/admin/transport/vehicle" className='bredcrumText text-decoration-none'>Vehicle</a></li>
                                <li className="breadcrumb-item active bredcrumActiveText" aria-current="page">Add Vehicle</li>
                            </ol>
                        </nav>
                        <p className='font14 ps-0 fontWeight500'>Add Vehicle Form</p>
                    </div>
                    <div className="row pb-3">
                        <div className="bg-white rounded-2 p-4">
                            <form className="row g-3" onSubmit={handleSubmit(AddNewVehicle)}>
                                <div className="col-md-6 col-sm-12 col-12">
                                    <label htmlFor="vehicleNo" className="form-label font14">Vehicle Number <span className='text-danger'>*</span></label>
                                    <input
                                        id="vehicleNo"
                                        type="text"
                                        className={`form-control font14 ${errors.vehicleNo ? 'border-danger' : ''}`}
                                        placeholder="Enter Vehicle Number"
                                        {...register('vehicleNo', {
                                            required: 'Vehicle Number is required *',
                                            pattern: {
                                                value: /^[A-Z]{2}\d{2}[A-Z]{2}\d{4}$/,
                                                message: 'Vehicle Number must be in valid format'
                                            }
                                        })}
                                        onInput={(e) => {
                                            e.target.value = e.target.value.toUpperCase();
                                        }}
                                    />

                                    {/* // validate: value => { if (!/^[A-Z0-9]+$/.test(value)) { return 'Vehicle Number can only contain uppercase letters and digits, no special characters or lowercase letters'; } return true; } */}
                                    {errors.vehicleNo && <p className="font12 text-danger">{errors.vehicleNo.message}</p>}
                                </div>
                                <div className="col-md-6 col-sm-12 col-12">
                                    <label htmlFor="vehicleModel" className="form-label font14">Vehicle Type <span className='text-danger'>*</span></label>
                                    <input id="vehicleModel" type="text" className={`form-control font14 ${errors.vehicleModel ? 'border-danger' : ''}`} placeholder="Enter Vehicle Type" {...register('vehicleModel', { required: 'Vehicle Type is required *', validate: value => { if (!/^[A-Za-zA-Z0-9-\s]*$/.test(value)) { return 'Vehicle Type must start with an uppercase letter and can only contain letters, digits, and hyphens (-)'; } return true; } })} />
                                    {errors.vehicleModel && <p className="font12 text-danger">{errors.vehicleModel.message}</p>}
                                </div>
                                <div className="col-md-6 col-sm-12 col-12">
                                    <label htmlFor="chassisNo" className="form-label font14">Chassis Number <span className='text-danger'>*</span></label>
                                    <input id="chassisNo" type="text" className={`form-control font14 ${errors.chassisNo ? 'border-danger' : ''}`} placeholder="Enter Chassis Number" {...register('chassisNo', { required: 'Chassis Number is required *' })} />
                                    {errors.chassisNo && <p className="font12 text-danger">{errors.chassisNo.message}</p>}
                                </div>
                                <div className="col-md-6 col-sm-12 col-12">
                                    <label htmlFor="driverId" className="form-label font14">Assign Driver <span className='text-danger'>*</span></label>
                                    <select id="driverId" className={`form-select font14 ${errors.driverId ? 'border-danger' : ''}`} {...register('driverId', { required: 'Driver selection is required *' })}>
                                        <option value="">Select Driver</option>
                                        {driverData.length > 0
                                            ?
                                            <>
                                                {driverData.map((driver) => (
                                                    <option key={driver.id} value={driver.id}>{driver.staffName}</option>
                                                ))}
                                            </>
                                            :
                                            <option disabled>
                                                <span>-- Add Driver Data First--</span>
                                                <button>Add Driver</button>
                                            </option>
                                        }
                                    </select>
                                    {errors.driverId && <p className="font12 text-danger">{errors.driverId.message}</p>}
                                </div>
                                <div className="col-md-6 col-sm-12 col-12">
                                    <label htmlFor="totalSeat" className="form-label font14">Seat Capacity <span className='text-danger'>*</span></label>
                                    <input id="totalSeat" type="number" className={`form-control font14 ${errors.totalSeat ? 'border-danger' : ''}`} placeholder="Enter Seat Capacity" {...register('totalSeat', { required: 'Seat Capacity is required *' })} />
                                    {errors.totalSeat && <p className="font12 text-danger">{errors.totalSeat.message}</p>}
                                </div>
                                <div className="col-md-6 col-sm-12 col-12">
                                    <label htmlFor="routeId" className="form-label font14">Route <span className='text-danger'>*</span></label>
                                    <select id="routeId" className={`form-select font14 ${errors.routeId ? 'border-danger' : ''}`} {...register('routeId', { required: 'Route selection is required *' })}>
                                        <option value="">Select Route</option>
                                        {allRouteData.length > 0
                                            ?
                                            <>
                                                {allRouteData.map((route) => (
                                                    <option key={route.routeId} value={route.routeId}>{route.routeName}</option>
                                                ))}
                                            </>
                                            :
                                            <option disabled>-- Add Route Data First--</option>
                                        }
                                    </select>
                                    {errors.routeId && <p className="font12 text-danger">{errors.routeId.message}</p>}
                                </div>
                                <div className="col-md-6 col-sm-12 col-12">
                                    <label htmlFor="status" className="form-label font14">Status <span className='text-danger'>*</span></label>
                                    <select id="status" className={`form-select font14 ${errors.status ? 'border-danger' : ''}`} {...register('status', { required: 'Status is required *' })}>
                                        <option value="">Select Status</option>
                                        <option value="active">Active</option>
                                        <option value="inactive">In Active</option>
                                    </select>
                                    {errors.status && <p className="font12 text-danger">{errors.status.message}</p>}
                                </div>
                                <div className="row p-5">
                                    <div className="col-md-6 col-sm-6 col-6 text-end">
                                        <button className="btn AddBtnn font14 text-white" type="submit">Add Vehicle</button>
                                    </div>
                                    <div className="col-md-6 col-sm-6 col-6 text-start">
                                        <button className="btn CancelBtnn font14" onClick={handleCancelBtn}>Cancel</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </Container>
        </>
    )
}

export default AddVehicle
