
import React, { useEffect, useState } from 'react';
import styled from 'styled-components';
import { AddStudentByCSVApi, DownloadStudentExcelForm, getAllClassApi } from '../../../Utils/Apis';
import { useForm } from 'react-hook-form';
import toast from 'react-hot-toast';
import { useNavigate } from 'react-router-dom';
import { CSVLink } from 'react-csv';

const Container = styled.div`
  .form-control::placeholder,
  .form-control,
  .form-select {
    color: var(--greyState);
    box-shadow: none !important;
  }

  .form-control,
  .form-select {
    border-radius: 5px;
    border: 1px solid var(--fontControlBorder);
  }

  .AddBtnn {
    width: fit-content;
    border: 1px solid var(--breadCrumActiveTextColor);
    background-color: var(--breadCrumActiveTextColor);
  }

  .EyeViewBtnn {
    width: fit-content;
    border: 1px solid var(--breadCrumActiveTextColor);
    background-color: var(--OrangeBtnColor);
  }
`;

const ExcelUpload = () => {

    const navigate = useNavigate('')
    const [csvData, setCsvData] = useState([]);
    const [allClassData, setAllClassData] = useState([]);
    const [allSectionData, setAllSectionData] = useState([]);
    const [loaderState, setLoaderState] = useState(false);

    const { register, handleSubmit, watch, formState: { errors }, setValue } = useForm({
        mode: 'onChange'
    });

    useEffect(() => {
        getAllClassData()
    }, [])

    const handleClassChange = (val) => {
        const classNoVal = val;
        setValue('classNo', classNoVal);
        console.log('classNo', classNoVal)
        const selectedClass = allClassData.find(c => c.classNo === classNoVal);

        if (selectedClass) {
            setAllSectionData(selectedClass.section || []);
            console.log(selectedClass.section)
        } else {
            setAllSectionData([]);
        }
    };

    const getAllClassData = async () => {
        try {
            var response = await getAllClassApi();
            if (response?.status === 200) {
                if (response?.data?.status === 'success') {
                    setAllClassData(response?.data?.classes);
                }
                else {
                    toast.error(response.data.message)
                }
            }
            else {
                toast.error(response.data.message)
            }
        }
        catch (error) {
            setLoaderState(false);
            toast.error(response.data.message)
        }
        finally {
            setLoaderState(false);
        }
    }


// const handleClassChange = (classNoVal) => {
//     setValue('classNo', classNoVal);
//     const selectedClass = allClassData.find((c) => c.classNo === classNoVal);
//     setAllSectionData(selectedClass?.section || []);
// };

const Download_Slip = async () => {
    try {
        const response = await DownloadStudentExcelForm();

        if (response?.status === 200 && response?.data?.csvUrl) {
            const fileUrl = response.data.csvUrl;
            console.log('xlsx value', fileUrl)

            const link = document.createElement('a');
            link.href = fileUrl;
            link.setAttribute('download', 'Student_List.xlsx');
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        } else {
            toast.error('Excel file URL not found');
        }
    } catch (err) {
        toast.error('Excel download failed');
    }
}
    return (
        <>
            <Container>
                <div className="container-fluid">
                    <div className="row">
                        <div className="pt-3">
                            {/* <CSVLink className='col-lg-2 col-md-3 col-sm-4 col-6 btn AddBtnn font14 text-white' data={csvData} filename={"GeneratedCsvForm.csv"} onClick={() => Download_Slip()}>
                                Generate XLSX File
                            </CSVLink> */}
                            <button className='col-lg-2 col-md-3 col-sm-4 col-6 btn AddBtnn font14 text-white' data={csvData} filename={"GeneratedCsvForm.csv"} onClick={() => Download_Slip()}>
                                Generate XLSX File
                            </button>
                            <button className='col-lg-2 col-md-3 col-sm-4 col-6 btn EyeViewBtnn font16 ms-2' data-bs-toggle="modal" data-bs-target="#abc">
                                <svg xmlns="http://www.w3.org/2000/svg" width="1.6em" height="1.6em" viewBox="0 0 16 16"><g fill="white"><path d="M10.5 8a2.5 2.5 0 1 1-5 0a2.5 2.5 0 0 1 5 0" /><path d="M0 8s3-5.5 8-5.5S16 8 16 8s-3 5.5-8 5.5S0 8 0 8m8 3.5a3.5 3.5 0 1 0 0-7a3.5 3.5 0 0 0 0 7" /></g></svg>
                            </button>
                        </div>
                        <form className="row g-3 m-0" onSubmit={handleSubmit(AddStudentByCSVApi)}>
                            <div className="col-md-6 col-sm-12 col-12">
                                <label htmlFor="classNo" className="form-label font14">Class <span className='text-danger'>*</span></label>
                                <select id="classNo" className={`form-select font14 ${errors.classNo ? 'border-danger' : ''}`} {...register('classNo', { required: 'Class is required *' })} onChange={(e) => handleClassChange(e.target.value)}>
                                    <option value="">Select Class</option>
                                    {allClassData.map((classs) => (<option key={classs.classId} value={classs.classNo}> {classs.classNo} </option>))}
                                </select>
                                {errors.classNo && <p className="font12 text-danger">{errors.classNo.message}</p>}
                            </div>
                            <div className="col-md-6 col-sm-12 col-12">
                                <label htmlFor="sectionName" className="form-label font14">Section <span className='text-danger'>*</span></label>
                                <select id="sectionName" className={`form-select font14 ${errors.sectionName ? 'border-danger' : ''}`} {...register('sectionName', { required: 'Section is required *' })} >
                                    <option value="">Select Section</option>
                                    {allSectionData.map((section) => (<option key={section.classSecId} value={section.sectionName}> {section.sectionName} </option>))}
                                </select>
                                {errors.sectionName && <p className="font12 text-danger">{errors.sectionName.message}</p>}
                            </div>
                            <div className="col-md-12 col-sm-12 col-12">
                                <label htmlFor="csvFile" className="form-label font14">Upload XLSX <span className='text-danger'>*</span></label>
                                <input id="csvFile" type="file" className={`form-control font14 ${errors.csvFile ? 'border-danger' : ''}`} accept=".xlsx" onChange={(e) => setValue('csvFile', e.target.files)} {...register('csvFile', { required: 'XLSX File is required *' })} />
                                {errors.csvFile && <p className="font12 text-danger">{errors.csvFile.message}</p>}
                            </div>
                            <button className='col-lg-2 col-md-3 col-sm-4 col-6 btn AddBtnn font14 text-white' type='submit'>+ Add Student</button>
                        </form>
                    </div>
                </div>

                <div className="modal modal-lg fade" id="abc" tabIndex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div className="modal-dialog modal-dialog-centered modal-xl">
                        <div className="modal-content">
                            <div className="modal-header">
                                <h1 className="modal-title greyTextt fontWeight700 font16" id="exampleModalLabel">CSV Format</h1>
                                <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                            </div>
                            <div className="modal-body p-0">
                                <table className="table table-bordered">
                                    <thead>
                                        <tr>
                                            <th className='font14 fontWeight600'>S.No</th>
                                            <th className='font14 fontWeight600'>Student Name</th>
                                            <th className='font14 fontWeight600'>Father Name</th>
                                            <th className='font14 fontWeight600'>Student Email</th>
                                            <th className='font14 fontWeight600'>Student Phone</th>
                                            <th className='font14 fontWeight600'>Blood Group</th>
                                            <th className='font14 fontWeight600'>Gender</th>
                                            <th className='font14 fontWeight600'>Birthday</th>
                                            <th className='font14 fontWeight600'>Address</th>
                                            <th className='font14 fontWeight600'>Parent's Email</th>
                                            <th className='font14 fontWeight600'>Parent Phone</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td className='font12'>1</td>
                                            <td className='font12'>xxx</td>
                                            <td className='font12'>xxx</td>
                                            <td className='font12'>xxx</td>
                                            <td className='font12'>xxx</td>
                                            <td className='font12'>xxx</td>
                                            <td className='font12'>xxx</td>
                                            <td className='font12'>xxx</td>
                                            <td className='font12'>xxx</td>
                                            <td className='font12'>xxx</td>
                                            <td className='font12'>xxx</td>
                                        </tr>
                                        <tr>
                                            <td className='font12'>2</td>
                                            <td className='font12'>xxx</td>
                                            <td className='font12'>xxx</td>
                                            <td className='font12'>xxx</td>
                                            <td className='font12'>xxx</td>
                                            <td className='font12'>xxx</td>
                                            <td className='font12'>xxx</td>
                                            <td className='font12'>xxx</td>
                                            <td className='font12'>xxx</td>
                                            <td className='font12'>xxx</td>
                                            <td className='font12'>xxx</td>
                                        </tr>
                                        <tr>
                                            <td className='font12'>3</td>
                                            <td className='font12'>xxx</td>
                                            <td className='font12'>xxx</td>
                                            <td className='font12'>xxx</td>
                                            <td className='font12'>xxx</td>
                                            <td className='font12'>xxx</td>
                                            <td className='font12'>xxx</td>
                                            <td className='font12'>xxx</td>
                                            <td className='font12'>xxx</td>
                                            <td className='font12'>xxx</td>
                                            <td className='font12'>xxx</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                           
                        </div>
                    </div>
                </div>
            </Container>
        </>
    )
}

export default ExcelUpload

// , validate: (value) => { if (value.length > 0 && (value[0].size < 10240 || value[0].size > 204800)) { return 'File size must be between 10 KB to 200 KB'; } return true; }, 






















{/* <div className="col-md-6 col-sm-12 col-12">
                                <label htmlFor="validationDefault02" className="form-label font14">Class*</label> // classNo
                                <input type="text" className="form-control font14" id="validationDefault02" placeholder="Select Class" required />
                            </div>
                            <div className="col-md-6 col-sm-12 col-12">
                                <label htmlFor="validationDefault01" className="form-label font14">Section*</label> // sectionName
                                <input type="text" className="form-control font14" id="validationDefault01" placeholder="Select Section" required />
                            </div>
                            <div className="col-md-12 col-sm-12 col-12">
                                <label htmlFor="validationDefault02" className="form-label font14">Upload CSV*</label> // csvFile
                                <input type="file" className="form-control font14" id="validationDefault02" placeholder="Select Class" required />
                            </div> */}
