import React, { useEffect, useState } from 'react';
import styled from 'styled-components';
import { Link } from 'react-router-dom';
import { Icon } from '@iconify/react';
import AddSamplePaper from 'src/Modals/SamplePapers/AddSamplePaper';
import EditSamplePaper from 'src/Modals/SamplePapers/EditSamplePaper';
import { DownloadSamplePaperExcel, DownloadSamplePaperPDF, deleteSamplePaperApi, getAllClassApi, getDownloadSamplePaperDataApi, getSearhSamplePaperDataApi } from '../../../Utils/Apis';
import DataLoader from 'src/Layouts/Loader';
import toast, { Toaster } from 'react-hot-toast';
import ReactPaginate from 'react-paginate';
import { CSVLink } from 'react-csv';
import ActionControls from '../../../Layouts/ActionControls';


const Container = styled.div`
    select:-internal-list-box {
        overflow: visible !important;
        background-color: #00A67E !important;
    }

    .form-select {
        color: var(--greyState);
        box-shadow: none;
        border: 1px solid var(--formInputBorder) !important;
    }
    
    .mainBreadCrum {
        --bs-breadcrumb-divider: '>' !important;
    }

    .bredcrumText {
        color: var(--breadCrumTextColor);
    }

    .bredcrumActiveText {
        color: var(--breadCrumActiveTextColor);
    }

    .ExportBtns {
        border-radius: 6px;
        border: 1.5px solid var(--fontControlBorder);
    }

    .form-control::placeholder, .form-control, .form-select {
        color: var(--greyState);
    }

    .form-control, .form-select {
        box-shadow: none !important;
        border: 1px solid var(--fontControlBorder);
    }

    .contbtn {
        margin-left: 41% !important;
        margin-top: -20% !important;
    }

    .greydiv {
        background-color: #FBFBFB;
    }
    .formdltcheck:checked {
        background-color: #B50000;
        border-color: #B50000;
    }

    .formEditSpecFeatcheck:checked {
        background-color: #00A67E;
        border-color: #00A67E;
    }

    .modalHighborder {
        border-bottom: 2px solid var(--modalBorderColor);
    }

    .modalLightBorder {
        border-bottom: 1px solid var(--modalBorderColor);
    }

    .correvtSVG {
        position: relative;
        width: fit-content;
        margin-left: 43% !important;
        margin-bottom: -16% !important;
        background-color: #2BB673;
        width: 73px;
        height: 73px;
        align-items: center;
    }

    .deleteSVG {
        position: relative;
        width: fit-content;
        margin-left: 43% !important;
        margin-bottom: -18% !important;
        background-color: #fff;
    }
`;

const SamplePaper = () => {
    // Loader State
    const [loaderState, setloaderState] = useState(false);

    const token = sessionStorage.getItem('token');
    const [SearchBtn, setSearchBtn] = useState(false);
    const [DeleteWarning, setDeleteWarning] = useState(true);
    const [isChecked, setIsChecked] = useState(false);
    const [searchByKey, setSearchByKey] = useState('');
    const [EditItemId, setEditItemId] = useState('');
    const [DeleteItemId, setDeleteItemId] = useState('');
    const [classNo, setClassNo] = useState('');
    const [classId, setClassId] = useState(0);
    const [sectionId, setSectionId] = useState(0);
    const [subjectId, setSubjectId] = useState(0);
    const [allClassData, setAllClassData] = useState([]);
    const [allSectionData, setAllSectionData] = useState([]);
    const [allSubjectData, setAllSubjectData] = useState([]);
    const [allSamplePaperData, setAllSamplePaperData] = useState([]);
    const [closeAddModal, setCloseAddModal] = useState(false);
    const [closeEditModal, setCloseEditModal] = useState(false);
    // CSV State
    const [csvData, setCSVData] = useState([]);
    const [PDFResponse, setPDFResponse] = useState();
    const [allowCsvPdf, setAllowCsvPdf] = useState(false);
    // Pagination
    const [currentPage, setCurrentPage] = useState(1);
    const [totalPages, setTotalPages] = useState(1);
    const [pageNo, setPageNo] = useState(1);
    const [pageSize, setPageSize] = useState(10);
    // Dropdown State
    const [isDropdownOpen, setIsDropdownOpen] = useState(null);

    useEffect(() => {
        setIsDropdownOpen(null);
        if (pageNo || closeAddModal || closeEditModal || allowCsvPdf) {
            getAllSamplePaper(searchByKey);
        }
        getAllClassData();
        if (closeAddModal) {
            const offcanvasElement = document.getElementById('add_staticBackdrop');
            if (offcanvasElement) {
                const offcanvas = bootstrap.Offcanvas.getInstance(offcanvasElement) || new bootstrap.Offcanvas(offcanvasElement);
                offcanvas.hide();
                offcanvasElement.addEventListener('hidden.bs.offcanvas', () => {
                    const backdrop = document.querySelector('.offcanvas-backdrop');
                    if (backdrop) {
                        backdrop.remove();
                    }
                }, { once: true });
                // Explicitly remove backdrop
                const backdrops = document.querySelectorAll('.offcanvas-backdrop');
                backdrops.forEach(backdrop => backdrop.remove());
            }
            setCloseAddModal(false);
            getAllClassData();
        }
        if (closeEditModal) {
            const offcanvasElement = document.getElementById('Edit_staticBackdrop');
            if (offcanvasElement) {
                const offcanvas = bootstrap.Offcanvas.getInstance(offcanvasElement) || new bootstrap.Offcanvas(offcanvasElement);
                offcanvas.hide();
                offcanvasElement.addEventListener('hidden.bs.offcanvas', () => {
                    const backdrop = document.querySelector('.offcanvas-backdrop');
                    if (backdrop) {
                        backdrop.remove();
                    }
                }, { once: true });
                // Explicitly remove backdrop
                const backdrops = document.querySelectorAll('.offcanvas-backdrop');
                backdrops.forEach(backdrop => backdrop.remove());
            }
            setCloseEditModal(false);
            getAllClassData();
        }
    }, [token, pageNo, closeAddModal, closeEditModal, allowCsvPdf]);

    const handleClassChange = (value) => {
        const val = parseInt(value);
        setClassId(val);
        const selectedClass = allClassData.find(c => c.classId === val);
        if (selectedClass) {
            setAllSectionData(selectedClass.section || []);
            setAllSubjectData(selectedClass.subjects || []);
        } else {
            setAllSectionData([]);
            setAllSubjectData([]);
        }
    };

    const handlePageClick = (event) => {
        setPageNo(event.selected + 1);
    };

    const getAllSamplePaper = async (searchKey) => {
        if (classId > 0 || sectionId > 0 || subjectId > 0) {
            try {
                setSearchBtn(true);
                setloaderState(true);
                var response = await getSearhSamplePaperDataApi(classId, sectionId, subjectId, searchKey === 'search' ? '' : searchKey, pageNo, pageSize);
                if (response?.status === 200) {
                    if (response?.data?.status === 'success') {
                        setTimeout(() => {
                            setloaderState(false);
                        }, 300);
                        setAllSamplePaperData(response?.data?.samplePaper);
                        setTotalPages(response.data.totalPages);
                        setCurrentPage(response.data.currentPage);
                        setAllowCsvPdf(true);
                    }
                } else {
                    setTimeout(() => {
                        setloaderState(false);
                    }, 300);
                }
            } catch (e) {
                setTimeout(() => {
                    setloaderState(false);
                }, 300);
            }
            finally {
                setloaderState(false);
            }
        }
    };

    const downloadFileFunction = (blob, filename) => {
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        window.URL.revokeObjectURL(url);
    };

    const downloadSamplePaper = async (id) => {
        try {
            setloaderState(true);

            // Remove responseType: "blob" — we expect JSON with base64
            const response = await getDownloadSamplePaperDataApi(id); // no extra data param needed

            if (response?.status === 200 && response?.data?.status === "success") {
                const base64String = response.data.pdf;

                // Convert Base64 to binary
                const binaryString = window.atob(base64String);
                const bytes = new Uint8Array(binaryString.length);
                for (let i = 0; i < binaryString.length; i++) {
                    bytes[i] = binaryString.charCodeAt(i);
                }

                // Create proper PDF Blob
                const blob = new Blob([bytes], { type: 'application/pdf' });

                // Trigger download
                const url = window.URL.createObjectURL(blob);
                const a = document.createElement('a');
                a.href = url;
                a.download = 'SamplePaper.pdf';
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);
                window.URL.revokeObjectURL(url);

                toast.success('Sample Paper Downloaded Successfully');
            } else {
                toast.error('Failed to download the Sample Paper.');
            }
        } catch (error) {
            console.error('Download error:', error);
            toast.error('An error occurred while downloading the Sample Paper.');
        } finally {
            setTimeout(() => {
                setloaderState(false);
            }, 300);
        }
    };

    const getAllClassData = async () => {
        try {
            setloaderState(true);
            var response = await getAllClassApi();
            if (response?.status === 200) {
                if (response?.data?.status === 'success') {
                    setTimeout(() => {
                        setloaderState(false);
                    }, 300);
                    setAllClassData(response?.data?.classes);
                }
            } else {
                setTimeout(() => {
                    setloaderState(false);
                }, 300);
            }
        } catch (error) {
            setloaderState(false);
            if (error?.response?.data?.statusCode === 401) {
                sessionStorage.removeItem('token');
                setTimeout(() => {
                    navigate('/');
                }, 200);
            }
        }
        finally {
            setloaderState(false);
        }
    };

    const DeleteSamplePaperDataById = async (id) => {
        if (isChecked) {
            try {
                var response = await deleteSamplePaperApi(id);
                if (response?.status === 200) {
                    if (response.data.status === 'success') {
                        toast.success(response?.data?.message);
                        const offcanvasElement = document.getElementById('Delete_staticBackdrop');
                        if (offcanvasElement) {
                            const offcanvas = bootstrap.Offcanvas.getInstance(offcanvasElement) || new bootstrap.Offcanvas(offcanvasElement);
                            offcanvas.hide();
                            offcanvasElement.addEventListener('hidden.bs.offcanvas', () => {
                                const backdrop = document.querySelector('.offcanvas-backdrop');
                                if (backdrop) {
                                    backdrop.remove();
                                }
                            }, { once: true });
                            // Explicitly remove all backdrops
                            const backdrops = document.querySelectorAll('.offcanvas-backdrop');
                            backdrops.forEach(backdrop => backdrop.remove());
                        }
                        getAllSamplePaper('');
                        setIsChecked(false);
                    }
                } else {
                    toast.error(response?.error);
                }
            } catch (error) {
                setloaderState(false);
                console.error('Error during login:', error);
            }
            finally {
                setloaderState(false);
            }
        }
    };

    const handleAddSampleModal = () => {
        setCloseAddModal(true);
    };

    const handleEditSampleModal = () => {
        setCloseEditModal(true);
    };

    const cancelSearch = () => {
        setClassId(0);
        setSectionId(0);
        setSubjectId(0);
        setAllSamplePaperData([])
        getAllSamplePaper('');
    };

    const toggleDropdown = (index) => {
        setIsDropdownOpen(isDropdownOpen === index ? null : index);
    };

    const handleSearchButton = () => {
        getAllSamplePaper(searchByKey);
    };

    const openAddCanvas = () => {
        const offcanvasElement = document.getElementById('add_staticBackdrop');
        const bsOffcanvas = new bootstrap.Offcanvas(offcanvasElement);
        bsOffcanvas.show();
    };

    return (
        <>
            <Container>
                {loaderState && <DataLoader />}
                <div className="container-fluid p-4">
                    <div className="row pb-3 gap-xl-0 gap-3">
                        <div className="col-xxl-4 col-xl-3 col-lg-12 col-sm-12 flex-frow-1">
                            <nav className='mainBreadCrum font14 ps-0' aria-label="breadcrumb">
                                <ol className="breadcrumb mb-1">
                                    <li className="breadcrumb-item"><a href="/" className='bredcrumText text-decoration-none'>Home</a></li>
                                    <li className="breadcrumb-item active bredcrumActiveText" aria-current="page">SamplePaper</li>
                                </ol>
                            </nav>
                            <p className='font14 ps-0 fontWeight500'>SamplePaper</p>
                        </div>
                        <div className="col-xxl-8 col-xl-9 col-lg-12 col-sm-12 pe-0">
                            <ActionControls
                                showAddButton={true}
                                addButtonText="Add Sample Paper"
                                addButtonAction={openAddCanvas}
                                showSearch={true}
                                searchAction={handleSearchButton}
                                showExportPDF={false}
                                exportPDFText="Export PDF"
                                exportPDFAction={DownloadSamplePaperPDF}
                                exportPDFFileName="Sample Paper.pdf"
                                showExportCSV={allSamplePaperData.length > 0}
                                exportCSVText="Export XLSX"
                                exportCSVAction={DownloadSamplePaperExcel}
                                exportCSVFileName="Sample PAper.xlsx"
                            />
                        </div>
                    </div>
                    <div className="row pb-3">
                        <div className="bg-white rounded-2 p-4">
                            <form className="row g-3">
                                <div className="col-md-4 col-sm-6 col-12">
                                    <label htmlFor="inputEmail4" className="form-label font14">Class</label>
                                    <select className="form-select bordeRadius5 font14" aria-label="Default select example" value={classId} onChange={(e) => handleClassChange(e.target.value)}>
                                        <option value="">-- Select --</option>
                                        {allClassData?.map((option) => (
                                            <option key={option.classId} value={option?.classId}>
                                                {option?.classNo}
                                            </option>
                                        ))}
                                    </select>
                                </div>
                                <div className="col-md-4 col-sm-6 col-12">
                                    <label htmlFor="inputEmail4" className="form-label font14">Section</label>
                                    <select className="form-select bordeRadius5 font14" aria-label="Default select example" value={sectionId} onChange={(e) => setSectionId(e.target.value)}>
                                        <option value="">-- Select --</option>
                                        {allSectionData?.map(option => (
                                            <option key={option.classSecId} value={option.classSecId}>
                                                {option.sectionName}
                                            </option>
                                        ))}
                                    </select>
                                </div>
                                <div className="col-md-4 col-sm-6 col-12">
                                    <label htmlFor="inputEmail4" className="form-label font14">Subject</label>
                                    <select className="form-select bordeRadius5 font14" aria-label="Default select example" value={subjectId} onChange={(e) => setSubjectId(e.target.value)}>
                                        <option value="">-- Select --</option>
                                        {allSubjectData?.map((option) => (
                                            <option key={option.subjectId} value={option.subjectId}>
                                                {option.subjectName}
                                            </option>
                                        ))}
                                    </select>
                                </div>
                                <p className='text-center p-3'>
                                    <button type='button' className='btn addCategoryButtons text-white' onClick={() => getAllSamplePaper('')} disabled={classId === 0 || sectionId === 0 || subjectId === 0 ? true : false}>Search</button>
                                    <button type='button' className='btn cancelButtons ms-3' onClick={cancelSearch}>Cancel</button>
                                </p>
                            </form>
                            {SearchBtn ? (
                                <div className="row">
                                    {allSamplePaperData && allSamplePaperData.length === 0 ? (
                                        <div className="d-flex justify-content-center p-5">
                                            <img onError={(e) => { e.target.onerror = null; e.target.src = "/images/fallback.png"; }} src="/images/search.svg" alt="" className='img-fluid' />
                                        </div>
                                    ) : (
                                        <>
                                            <div className="overflow-scroll">
                                                <table className="table align-middle table-striped">
                                                    <thead>
                                                        <tr>
                                                            <th className='textWrapClass tableHeading text-center'><span className='font14'>#</span></th>
                                                            <th className='textWrapClass tableHeading'><span className='font14'>Title</span></th>
                                                            <th className='textWrapClass tableHeading'><span className='font14'>Class</span></th>
                                                            <th className='textWrapClass tableHeading'><span className='font14'>Section</span></th>
                                                            <th className='textWrapClass tableHeading'><span className='font14'>Subject</span></th>
                                                            <th className='textWrapClass tableHeading'><span className='font14'>Teacher</span></th>
                                                            <th className='textWrapClass tableHeading'><span className='font14'>Download</span></th>
                                                            <th className='textWrapClass tableHeading text-center'><span className='font14'>Action</span></th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        {allSamplePaperData.map((item, index) => (
                                                            <tr key={item.sampleId} className='align-middle'>
                                                                <th className='textWrapClass text-center greyText'><span className='font14'>{index + 1}</span></th>
                                                                <td className='textWrapClass greyText'>
                                                                    <span className='font14 align-self-start'>{item.title}</span>
                                                                </td>
                                                                <td className='textWrapClass greyText'>
                                                                    <span className='font14 align-self-start'>{item.classNo}</span>
                                                                </td>
                                                                <td className='textWrapClass greyText'>
                                                                    <span className='font14 align-self-start'>{item.sectionName}</span>
                                                                </td>
                                                                <td className='textWrapClass greyText'>
                                                                    <span className='font14 align-self-start'>{item.subjectName}</span>
                                                                </td>
                                                                <td className='textWrapClass greyText'>
                                                                    <span className='font14 align-self-start'>{item.teacherName}</span>
                                                                </td>
                                                                <td className='textWrapClass greyText'>
                                                                    <p className='font14 align-self-start m-0'>
                                                                        <Icon icon="bxs:file-pdf" width="1.3em" height="1.3em" style={{ color: 'red' }} />
                                                                        <Link className='ms-2' to='' onClick={() => downloadSamplePaper(item.sampleId)}>Download</Link>
                                                                    </p>
                                                                </td>
                                                                <td className='textWrapClass text-center'>
                                                                    <div className="dropdown dropdownbtn">
                                                                        <button className="btn btn-sm actionButtons dropdown-toggle" type="button" onClick={() => toggleDropdown(index)}>
                                                                            <span>Action</span>
                                                                        </button>
                                                                        <ul className={`dropdown-menu dropdown-menu-end ${isDropdownOpen === index ? 'show ' : ''}`}>
                                                                            <li>
                                                                                <button
                                                                                    className="dropdown-item greyText"
                                                                                    type="button"
                                                                                    data-bs-toggle="offcanvas"
                                                                                    data-bs-target="#Edit_staticBackdrop"
                                                                                    aria-controls="Edit_staticBackdrop"
                                                                                    onClick={() => { setEditItemId(item.sampleId); setCloseEditModal(false); }}
                                                                                >
                                                                                    Edit
                                                                                </button>
                                                                            </li>
                                                                            <li>
                                                                                <button
                                                                                    className="dropdown-item greyText"
                                                                                    type="button"
                                                                                    data-bs-toggle="offcanvas"
                                                                                    data-bs-target="#Delete_staticBackdrop"
                                                                                    aria-controls="Delete_staticBackdrop"
                                                                                    onClick={() => setDeleteItemId(item.sampleId)}
                                                                                >
                                                                                    Delete
                                                                                </button>
                                                                            </li>
                                                                        </ul>
                                                                    </div>
                                                                </td>
                                                            </tr>
                                                        ))}
                                                    </tbody>
                                                </table>
                                            </div>
                                            <div className="d-flex">
                                                <p className='font14'>Showing {currentPage} of {totalPages} Pages</p>
                                                <div className="ms-auto">
                                                    <ReactPaginate
                                                        previousLabel={<Icon icon="tabler:chevrons-left" width="1.4em" height="1.4em" />}
                                                        nextLabel={<Icon icon="tabler:chevrons-right" width="1.4em" height="1.4em" />}
                                                        breakLabel={'...'} breakClassName={'break-me'} pageCount={totalPages} marginPagesDisplayed={2} pageRangeDisplayed={10}
                                                        onPageChange={handlePageClick} containerClassName={'pagination'} subContainerClassName={'pages pagination'} activeClassName={'active'}
                                                    />
                                                </div>
                                            </div>
                                        </>
                                    )}
                                </div>
                            ) : (
                                <div className="d-flex justify-content-center p-5">
                                    <img onError={(e) => { e.target.onerror = null; e.target.src = "/images/fallback.png"; }} src="/images/search.svg" alt="" className='img-fluid' />
                                </div>
                            )}
                        </div>
                    </div>

                    {/* Add */}
                    <div className="offcanvas offcanvas-end p-2" data-bs-backdrop="static" tabIndex="-1" id="add_staticBackdrop" aria-labelledby="staticBackdropLabel">
                        <div className="offcanvas-header border-bottom border-2 p-1">
                            <Link
                                type="button"
                                data-bs-dismiss="offcanvas"
                                aria-label="Close"
                                onClick={() => {
                                    const offcanvasElement = document.getElementById('add_staticBackdrop');
                                    const offcanvas = bootstrap.Offcanvas.getInstance(offcanvasElement) || new bootstrap.Offcanvas(offcanvasElement);
                                    offcanvas.hide();
                                    offcanvasElement.addEventListener('hidden.bs.offcanvas', () => {
                                        const backdrop = document.querySelector('.offcanvas-backdrop');
                                        if (backdrop) {
                                            backdrop.remove();
                                        }
                                    }, { once: true });
                                    const backdrops = document.querySelectorAll('.offcanvas-backdrop');
                                    backdrops.forEach(backdrop => backdrop.remove());
                                }}
                            >
                                <svg xmlns="http://www.w3.org/2000/svg" width="2em" height="2em" viewBox="0 0 16 16">
                                    <path fill="#008479" fillRule="evenodd" d="M15 8a.5.5 0 0 0-.5-.5H2.707l3.147-3.146a.5.5 0 1 0-.708-.708l-4 4a.5.5 0 0 0 0 .708l4 4a.5.5 0 0 0 .708-.708L2.707 8.5H14.5A.5.5 0 0 0 15 8" />
                                </svg>
                            </Link>
                            <h2 className="offcanvas-title" id="staticBackdropLabel">Sample Paper Add</h2>
                        </div>
                        <div className="offcanvas-body p-0">
                            <AddSamplePaper addedSuccess={handleAddSampleModal} />
                        </div>
                    </div>

                    {/* Edit */}
                    <div className="offcanvas offcanvas-end p-2" data-bs-backdrop="static" tabIndex="-1" id="Edit_staticBackdrop" aria-labelledby="staticBackdropLabel">
                        <div className="offcanvas-header border-bottom border-2 p-1">
                            <Link
                                type="button"
                                data-bs-dismiss="offcanvas"
                                aria-label="Close"
                                onClick={() => {
                                    const offcanvasElement = document.getElementById('Edit_staticBackdrop');
                                    const offcanvas = bootstrap.Offcanvas.getInstance(offcanvasElement) || new bootstrap.Offcanvas(offcanvasElement);
                                    offcanvas.hide();
                                    offcanvasElement.addEventListener('hidden.bs.offcanvas', () => {
                                        const backdrop = document.querySelector('.offcanvas-backdrop');
                                        if (backdrop) {
                                            backdrop.remove();
                                        }
                                    }, { once: true });
                                    const backdrops = document.querySelectorAll('.offcanvas-backdrop');
                                    backdrops.forEach(backdrop => backdrop.remove());
                                }}
                            >
                                <svg xmlns="http://www.w3.org/2000/svg" width="2em" height="2em" viewBox="0 0 16 16">
                                    <path fill="#008479" fillRule="evenodd" d="M15 8a.5.5 0 0 0-.5-.5H2.707l3.147-3.146a.5.5 0 1 0-.708-.708l-4 4a.5.5 0 0 0 0 .708l4 4a.5.5 0 0 0 .708-.708L2.707 8.5H14.5A.5.5 0 0 0 15 8" />
                                </svg>
                            </Link>
                            <h2 className="offcanvas-title" id="staticBackdropLabel">SamplePaper Edit</h2>
                        </div>
                        <div className="offcanvas-body p-0">
                            <EditSamplePaper EditItemId={EditItemId} EditedSuccess={handleEditSampleModal} />
                        </div>
                    </div>

                    {/* Delete */}
                    <div className="offcanvas offcanvas-end p-2" data-bs-backdrop="static" tabIndex="-1" id="Delete_staticBackdrop" aria-labelledby="staticBackdropLabel">
                        <div className="offcanvas-header ps-0 modalHighborder p-1">
                            <Link
                                type="button"
                                data-bs-dismiss="offcanvas"
                                aria-label="Close"
                                onClick={() => {
                                    const offcanvasElement = document.getElementById('Delete_staticBackdrop');
                                    const offcanvas = bootstrap.Offcanvas.getInstance(offcanvasElement) || new bootstrap.Offcanvas(offcanvasElement);
                                    offcanvas.hide();
                                    offcanvasElement.addEventListener('hidden.bs.offcanvas', () => {
                                        const backdrop = document.querySelector('.offcanvas-backdrop');
                                        if (backdrop) {
                                            backdrop.remove();
                                        }
                                    }, { once: true });
                                    const backdrops = document.querySelectorAll('.offcanvas-backdrop');
                                    backdrops.forEach(backdrop => backdrop.remove());
                                    setIsChecked(false);
                                }}
                            >
                                <svg xmlns="http://www.w3.org/2000/svg" width="2em" height="2em" viewBox="0 0 16 16">
                                    <path fill="#B50000" fillRule="evenodd" d="M15 8a.5.5 0 0 0-.5-.5H2.707l3.147-3.146a.5.5 0 1 0-.708-.708l-4 4a.5.5 0 0 0 0 .708l4 4a.5.5 0 0 0 .708-.708L2.707 8.5H14.5A.5.5 0 0 0 15 8" />
                                </svg>
                            </Link>
                            <span className="offcanvas-title" id="staticBackdropLabel">SamplePaper</span>
                        </div>
                        <div className="offcanvas-body p-0">
                            <div>
                                <div className=''>
                                    <p className='modalLightBorder p-2'>SamplePaper</p>
                                    <p className='text-center p-3'> <img onError={(e) => { e.target.onerror = null; e.target.src = "/images/fallback.png"; }} src="/images/errorI.svg" className='img-fluid' alt="" /></p>
                                    <p className='text-center warningHeading'>Are you Sure?</p>
                                    <p className='text-center greyText warningText pt-2'>This Action will permanently delete<br />the Sample Paper Data</p>
                                    <p className='text-center warningText p-2'>
                                        <input
                                            className="form-check-input formdltcheck me-2"
                                            type="checkbox"
                                            checked={isChecked}
                                            id="flexCheckChecked"
                                            onChange={(e) => setIsChecked(e.target.checked)}
                                        />
                                        I Agree to delete the Sample Paper Data
                                    </p>
                                    <p className='text-center p-3'>
                                        <button
                                            className='btn deleteButtons text-white'
                                            onClick={() => DeleteSamplePaperDataById(DeleteItemId)}
                                        >
                                            Delete
                                        </button>
                                        <button
                                            className='btn dltcancelButtons ms-3'
                                            data-bs-dismiss="offcanvas"
                                            aria-label="Close"
                                            onClick={() => {
                                                const offcanvasElement = document.getElementById('Delete_staticBackdrop');
                                                const offcanvas = bootstrap.Offcanvas.getInstance(offcanvasElement) || new bootstrap.Offcanvas(offcanvasElement);
                                                offcanvas.hide();
                                                offcanvasElement.addEventListener('hidden.bs.offcanvas', () => {
                                                    const backdrop = document.querySelector('.offcanvas-backdrop');
                                                    if (backdrop) {
                                                        backdrop.remove();
                                                    }
                                                }, { once: true });
                                                const backdrops = document.querySelectorAll('.offcanvas-backdrop');
                                                backdrops.forEach(backdrop => backdrop.remove());
                                                setIsChecked(false);
                                            }}
                                        >
                                            Cancel
                                        </button>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </Container>
        </>
    );
};

export default SamplePaper;
